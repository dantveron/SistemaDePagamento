## Tarefas para reescrever e melhorar o prompt:

### Fase 1: Análise do erro e estrutura do projeto
- [x] Entender o contexto completo do projeto (framework, estrutura de pastas, etc.).
- [x] Confirmar a versão do Node.js e Yarn/npm utilizada. (Node.js v22.13.0, Yarn/npm não é o principal, mas sim Bun para dev e Next build para build. O erro original pode ser de um ambiente diferente ou comando incorreto.)
- [x] Obter o código-fonte do projeto para análise.

### Fase 2: Pesquisa de melhores práticas web
- [x] Pesquisar as melhores práticas para gerenciamento de dependências em projetos React.
- [x] Investigar a integração de Heroicons em projetos React e possíveis problemas de compatibilidade. (O projeto usa `react-icons` e tenta importar `heroicons` diretamente, mas `heroicons` é um pacote separado e não está listado nas dependências. O erro original indica que o `@heroicons/react` não foi encontrado.)
- [x] Buscar por padrões de projeto e otimização de performance para aplicações web.

### Fase 3: Reescrita e otimização do código
- [x] Propor alterações no `package.json` para resolver as dependências.
- [x] Sugerir melhorias na estrutura de importação de componentes.
- [x] Otimizar o código para melhor performance e legibilidade.

### Fase 4: Entrega do prompt corrigido
- [x] Apresentar o prompt reescrito e as justificativas para as alterações.
- [x] Fornecer instruções claras para o usuário aplicar as correções.

