import { z } from "zod";

/**
 * @description Configuração do Schema de Login
 * @author ValoraPay
 */
export const LoginSchema = z.object({
  email: z
    .string({ required_error: "Campo obrigatório" })
    .min(1, { message: "Campo obrigatório" })
    .email("E-mail inválido"),
    
  password: z
    .string({ required_error: "Campo obrigatório" })
    .min(1, { message: "Campo obrigatório" })
    .min(6, { message: "A senha precisa ter no mínimo 6 caracteres" }),
});


/**
 * @description Configuração do Schema de Registro
 * @author ValoraPay
 */

const telefoneRegex = /^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$/;

export const RegisterSchema = z.object({
    nome: z.string().min(3).max(20),
    sobrenome: z.string().min(3).max(20),
    telefone: z.string().regex(telefoneRegex, "Telefone inválido"),
    email: z.string().email(),
    password: z.string().min(8),
});

export const RegisterSchemaStep1 = z
.object({
    nome: z.string().min(3, "Username must be at least 3 characters").max(20),
    sobrenome:  z.string().min(3, "Username must be at least 3 characters").max(20),
});

export const RegisterSchemaStep2 = z.
object({
    email: z.string().email("Invalid email addres"),
    telefone: z.string().regex(telefoneRegex, "Telefone inválido"),
});

export const RegisterSchemaStep3 = z
.object({
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
})
.refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});