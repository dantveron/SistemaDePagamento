import { z } from "zod";

export const PixRequestSchema = z.object({
  amount: z.number().min(100),
  customer: z.object({
    name: z.string(),
    email: z.string().email().optional(),  // email opcional
    document: z.string(),  // CPF/CNPJ como string
  }),
});
