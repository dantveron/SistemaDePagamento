"use server";

import { CreateClient, PegarUsuarioLogado } from "@/lib/appwrite";
import { ID } from "node-appwrite";

export async function createProductAction(formData: FormData, selectedType: string | null) {

    const nomeDoProduto = formData.get("product-name");
    const descricaoDoProduto = formData.get("description");

    if (!nomeDoProduto || !descricaoDoProduto) {
        return {
            message: "Todos os campos são obrigatorios",
            success: false
        }
    }

    const { databases } = await CreateClient();
    const DATABASE_ID =  process.env.DATABASE_ID!;
    const PRODUCT_COLLECTION = process.env.PRODUCT_COLLECTION!;
    const CHCEKOUT_COLLECTION = process.env.CHECKOUT_COLLECTION!;

    const produtorId = await PegarUsuarioLogado();
    const ProdutoId = ID.unique();
    const CheckoutId = ID.unique();
    try {
        /* cria produto na coleção de produtos */
        await databases.createDocument(
            DATABASE_ID,
            PRODUCT_COLLECTION,
            ID.unique(),
            {
                Id: ProdutoId,
                Titulo: nomeDoProduto,
                Descricao: descricaoDoProduto,
                ProdutorId: produtorId?.$id,
                CheckoutId: CheckoutId,
                Tipo: selectedType || "Digital",
                CreatedAt: new Date().toISOString(),
            }
        );

        /* cria checkout do produto  */
        await databases.createDocument(
            DATABASE_ID,
            CHCEKOUT_COLLECTION,
            ID.unique(),
            {
                Id: CheckoutId,
                ProdutoId: ProdutoId,
            }
        )

        console.log("Product created successfully");
        return { success: true };

    } catch (error: unknown) {
        console.error("Error creating product:", error);
        return { success: false, error: (error as Error).message };
    }

}