import { NextRequest, NextResponse } from "next/server";
import { CreateClient } from "@/lib/appwrite";
import { Query } from "node-appwrite";

const DATABASE_ID = process.env.DATABASE_ID!;
const COLLECTION_API_KEYS = process.env.COLLECTION_API_KEYS!;

export async function authenticate(request: NextRequest) {
  try {
    const client_id = request.headers.get("client-id");
    const client_secret = request.headers.get("client-secret");
    
    // Agora você pode usar client_id e client_secret para autenticar
    if (!client_id || !client_secret) {
      return NextResponse.json({ error: "Client-Id e Client-Secret são obrigatórios nos headers" }, { status: 401 });
    }
    const { databases } = await CreateClient();

    const result = await databases.listDocuments(DATABASE_ID, COLLECTION_API_KEYS, [
      Query.equal("ClientId", client_id),
      Query.equal("ClientSecret", client_secret)
    ]);

    if (result.documents.length === 0) {
      return NextResponse.json({ error: "Credenciais inválidas." }, { status: 403 });
    }

    const document = result.documents[0];

    return {
      UserId: document.UserId,
      ClientId: document.ClientId,
      ClientSecret: document.ClientSecret
    };

  } catch (err) {
    console.error("Erro na autenticação:", err);
    return NextResponse.json({ error: "Erro interno na autenticação." }, { status: 500 });
  }
}
