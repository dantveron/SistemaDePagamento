"use server";

import { CreateClient, PegarUsuarioLogado } from "@/lib/appwrite";
import { ID } from "node-appwrite";
import crypto from "crypto";

const DATABASE_ID = process.env.DATABASE_ID!;
const COLLECTION_API_KEYS = process.env.COLLECTION_API_KEYS!;

function generateToken(length = 24) {
  return crypto.randomBytes(length).toString("hex");
}

export async function generateCredentials(formData: FormData) {
  const nomeDoProduto = formData.get("name");

  if (!nomeDoProduto || typeof nomeDoProduto !== "string") {
    return { success: false, error: "Nome do produto inválido." };
  }

  try {
    const user = await PegarUsuarioLogado();
    if (!user) {
      return { success: false, error: "Usuário não autenticado." };
    }

    const { databases } = await CreateClient();

    const clientId = generateToken(12); 
    const clientSecret = generateToken(32);

    await databases.createDocument(
      DATABASE_ID,
      COLLECTION_API_KEYS,
      ID.unique(),
      {
        Id: ID.unique(),
        UserId: user.$id,
        ClientId: clientId,
        ClientSecret: clientSecret,
        Nome: nomeDoProduto
      }
    );

    return {
      success: true,
    };
  } catch (error) {
    console.error("Erro ao gerar credenciais:", error);
    return {
      success: false,
      error: (error as Error).message
    };
  }
}
