import { RevenueChart } from "@/components/charts-dashboard/total-revenue"

export const dynamic = "force-dynamic"

export default function DashboardPage() {
    return (
        <div className="w-full bg-neutral-900 min-h-screen flex flex-col p-5 items-center">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <RevenueChart />
                <RevenueChart />
            </div>
        </div>
    )
}