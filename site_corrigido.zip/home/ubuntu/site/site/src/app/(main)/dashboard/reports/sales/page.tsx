export const dynamic = "force-dynamic"

export default function SalesPage() {
    return (
        <div>
            
        </div>
    )
}