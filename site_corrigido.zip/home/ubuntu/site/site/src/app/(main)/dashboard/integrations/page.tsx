import { MdArrowForward } from "react-icons/md";
import { FaCodeBranch } from "react-icons/fa6";
import Link from "next/link";
export const dynamic = "force-dynamic";

export default function IntegrationsPage() {
  return (
    <div className="bg-white dark:bg-neutral-900 min-h-screen flex flex-col w-full">
      <header className="w-full"></header>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 items-center p-2 sm:p-6">
        <Link href={"/dashboard/integrations/api-valora"} className="bg-white dark:bg-neutral-900 group hover:bg-indigo-50 dark:hover:bg-neutral-800 rounded-2xl sm:rounded-3xl w-[390px] p-3 sm:px-4 sm:py-4 flex items-start justify-start border border-indigo-200 dark:border-neutral-700 transition-colors duration-200">
          <div className="bg-indigo-100 text-indigo-600 border border-indigo-400 dark:bg-neutral-800 dark:text-neutral-100 dark:border-neutral-700 w-[60px] h-[60px] sm:w-[55px] sm:h-[55px] rounded-xl sm:rounded-2xl flex items-center justify-center mr-3 sm:mr-2.5">
            <FaCodeBranch size={20} />
          </div>
          <div className="flex flex-col items-start justify-start w-full">
            <div className="flex items-start justify-between w-full">
              <span className="text-black dark:text-neutral-100 tracking-tight text-md font-semibold">
                Api - Cartão, Pix e Boleto
              </span>
              <MdArrowForward
                size={25}
                className="text-black dark:text-neutral-400"
              />
            </div>
            <p className="text-sm sm:text-xs text-neutral-500 dark:text-neutral-400 group-hover:text-indigo-500 dark:group-hover:text-neutral-200">
              Integre nossa API ao seu negócio — aumente suas vendas e tenha
              tudo junto em um só lugar
            </p>
          </div>
        </Link>
      </div>
    </div>
  );
}
