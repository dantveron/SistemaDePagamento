"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import { EditProductForm } from "@/components/forms/edit-product-form";
import { getProductData } from "@/data/user/get-produtc-data";
import { CreateClient } from "@/lib/appwrite";
import { EditProdutcNavbar } from "@/components/navbars/edit-produt/navbar";
import { RiLoader2Line } from "react-icons/ri";

export default function EditProductPage() {
  const { id } = useParams();
  const [product, setProduct] = useState<{
    title: string;
    description: string;
    price: number;
    banner: string;
  } | null>(null);
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;

    async function fetchData() {
      setLoading(true);
      setError(null);
      try {
        const data = await getProductData(id as string);
        setProduct(data);
      } catch (err) {
        setError("Failed to load product data.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      if (!product) return;

      const { databases, storage } = await CreateClient();
      const databaseId = process.env.DATABASE_ID!;
      const collectionId = process.env.COLLECTION_PRODUCTS!;
      const bucketId = process.env.STORAGE_BUCKET_ID!;

      let bannerUrl = product.banner;

      if (bannerFile) {
        const file = new File([bannerFile], bannerFile.name, { type: bannerFile.type });
        const uploadResponse = await storage.createFile(bucketId, "unique", file);
        bannerUrl = `https://cloud.appwrite.io/v1/storage/buckets/${bucketId}/files/${uploadResponse.$id}/view?project=${process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID}`;
      }

      await databases.updateDocument(databaseId, collectionId, id as string, {
        title: product.title,
        description: product.description,
        price: parseFloat(product.price.toString()),
        banner: bannerUrl,
      });

      alert("Product updated successfully.");
    } catch (err) {
      setError("Failed to update product.");
      console.error(err);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError("File size must be less than 5MB.");
        return;
      }
      if (!["image/png", "image/jpeg"].includes(file.type)) {
        setError("Only PNG and JPEG files are allowed.");
        return;
      }
      const img = new Image();
      img.onload = () => {
        if (img.width < 140 ||
            img.height < 140 ||
            img.width !== img.height) {
          setError("Image must be at least 140x140px and square.");
          return;
        }
        setBannerFile(file);
        setError(null);
      };
      img.src = URL.createObjectURL(file);
    }
  };

  return (
    <div className="w-full bg-neutral-900 flex p-5 flex-col items-center min-h-screen">
      <EditProdutcNavbar />

      {loading ? (
        <div className="w-full bg-neutral-900 flex flex-col items-center min-h-screen justify-center">
          <div className="flex items-center gap-1">
            <RiLoader2Line size={22} className="animate-spin" />
            <span>Carregando</span>
          </div>
        </div>
      ) : error ? (
        <div className="text-red-500">{error}</div>
      ) : !product ? (
        <div>Dados do Produto não encontrados</div>
      ) : (
        <EditProductForm
        product={{ 
          ...product, 
          onChange: (update) => {
            setProduct((prev) => {
              if (!prev) return prev;
              return {
                ...prev,
                ...update,
              };
            });
          },
        }}
        onSubmit={handleSubmit}
        onFileChange={handleFileChange}
        bannerFile={bannerFile}
        error={error}
      />
      )}

    </div>
  );
}
