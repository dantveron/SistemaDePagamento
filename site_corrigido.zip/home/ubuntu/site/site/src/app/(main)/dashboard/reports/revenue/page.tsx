export const dynamic = "force-dynamic"

export default function RevenuePage() {
    return (
        <div>
            
        </div>
    )
}