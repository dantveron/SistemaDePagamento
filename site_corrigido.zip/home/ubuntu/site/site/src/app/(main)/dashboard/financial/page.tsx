import { HandCoinsIcon } from "lucide-react";
import { AllCards } from "@/components/cards/financial/all-cards";
export const dynamic = "force-dynamic"

export default function FinacialPage() {
  return (
    <div className="bg-white dark:bg-neutral-900 flex flex-col w-full min-h-screen">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 items-center p-2 sm:p-6">
        <AllCards />
        {/* EFETUAR SAQUE */}
        <button className="bg-white dark:bg-neutral-900 group cursor-pointer hover:bg-blue-50 dark:hover:bg-neutral-800 rounded-2xl sm:rounded-3xl w-[390px] p-3 sm:px-4 sm:py-4 flex items-start justify-between border border-blue-200 dark:border-neutral-700 hover:border-blue-300 transition-colors">
          <div className="flex flex-col items-start justify-start">
            <div className="flex items-start justify-between w-full mb-1">
              <span className="text-black dark:text-neutral-100 tracking-tight text-md font-semibold">
                Efetuar Saque
              </span>
            </div>
            <p className="text-sm text-neutral-500 dark:text-neutral-400 tracking-tight font-medium">
              O dinheiro cairá na sua conta em até 1 dia útil
            </p>
          </div>
          <div className="bg-blue-500 border border-blue-400 dark:bg-transparent text-white dark:text-neutral-100 dark:border-neutral-600 w-[60px] h-[60px] sm:w-[55px] sm:h-[55px] rounded-xl sm:rounded-2xl flex items-center justify-center">
            <HandCoinsIcon size={25} />
          </div>
        </button>
      </div>

      {/* TÍTULOS DA TABELA */}
      <div className="flex p-2 sm:p-6">
        <div className="bg-neutral-100 dark:bg-neutral-800 w-full border-b border-neutral-400 dark:border-neutral-700 items-center justify-center rounded-b-none rounded-xl p-2 sm:p-3 py-4 grid grid-cols-3">
          <span className="text-neutral-500 dark:text-neutral-400 font-medium tracking-tight text-base">
            Data
          </span>
          <span className="text-neutral-500 dark:text-neutral-400 font-medium tracking-tight text-base">
            Valor líquido
          </span>
          <span className="text-neutral-500 dark:text-neutral-400 font-medium tracking-tight text-base">
            Status
          </span>
        </div>
      </div>
    </div>
  );
}
