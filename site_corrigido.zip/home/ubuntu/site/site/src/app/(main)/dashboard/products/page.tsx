import { CreateProducButton } from "@/components/buttons/create-produc"
import { ListProducts } from "@/components/lists/list-producs"
import { MdSearch } from "react-icons/md"
export const dynamic = "force-dynamic"

export default function ProductsPage() {
    return (
        <div className="bg-white dark:bg-neutral-900 min-h-screen flex flex-col w-full">

        <div className="w-full p-2 sm:p-6 flex items-start justify-between">
          <div className="realtive flex dark:bg-neutral-800 border border-black/10 w-full max-w-[250px] sm:max-w-xl rounded-xl py-3 px-1">
              <MdSearch size={25} className="translate-x-1/2 text-gray-500" />
              <input placeholder="Procure pelo Nome ou Id do produto" type="text" className="ml-5 flex text-black w-full focus:outline-none dark:text-white" />
          </div>
          <CreateProducButton />
        </div>
        <div className="flex flex-col p-2 w-full sm:p-6">
          <ListProducts />
        </div>
      </div>
    )
}