export const dynamic = "force-dynamic"

import Link from "next/link";
import { MdArrowForward } from "react-icons/md";
import {
  HandIcon,
  ArchiveIcon,
  BoxesIcon,
  Backpack,
  BlocksIcon,
  WorkflowIcon,
} from "lucide-react";

const MapaDeRelatorios = [
  {
    name: "Vendas Realizadas",
    icon: HandIcon,
    description: " Lista de todas as vendas concluídas.",
    url: "/reports/sales",
  },
  {
    name: "Vendas Abandonas",
    icon: ArchiveIcon,
    description: " Analise as taxas e as causas das vendas não finalizadas.",
    url: "/reports/abandoned-sales",
  },
  {
    name: "Receita por Produto/Serviço",
    icon: BoxesIcon,
    description: " Analise quanto cada item gerou de receita em um período.",
    url: "/reports/recipe-product",
  },
  {
    name: "Produtos Mais Vendidos",
    icon: Backpack,
    description: "Lista os produtos mais vendidos no período.",
    url: "/reports/revenue",
  },
  {
    name: "Estornos e Reembolsos",
    icon: BlocksIcon,
    description: " Lista de vendas que foram reembolsadas ou canceladas",
    url: "/reports/reimbursement",
  },
  {
    name: "Conversão de Pagamentos",
    icon: WorkflowIcon,
    description:
      "Mostra quantas pessoas: Iniciaram o checkout e outros",
    url: "/reports/conversion",
  },
];

export default function ReportsPage() {
  return (
    <div className="bg-white dark:bg-neutral-900 flex flex-col w-full min-h-screen">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 items-center p-2 sm:p-6">
        {MapaDeRelatorios.map((link) => (
          <Link
            href={link.url}
            key={link.name}
            className="bg-white dark:bg-neutral-900 group hover:bg-emerald-50 dark:hover:bg-neutral-800 rounded-2xl sm:rounded-3xl w-[390px] p-3 sm:px-4 sm:py-4 flex items-start justify-start border border-emerald-200 dark:border-neutral-700 transition-colors duration-200"
          >
            <div className="bg-emerald-100 text-emerald-600 border border-emerald-400 dark:bg-neutral-800 dark:text-neutral-100 dark:border-neutral-700 w-[60px] h-[60px] sm:w-[55px] sm:h-[55px] rounded-xl sm:rounded-2xl flex items-center justify-center mr-3 sm:mr-2.5">
              <link.icon size={25} />
            </div>
            <div className="flex flex-col items-start justify-start w-full">
              <div className="flex items-start justify-between w-full">
                <span className="text-black dark:text-neutral-100 tracking-tight text-md font-semibold">
                  {link.name}
                </span>
                <MdArrowForward
                  size={22}
                  className="text-black dark:text-neutral-400"
                />
              </div>
              <p className="text-sm sm:text-xs text-neutral-500 dark:text-neutral-400 group-hover:text-emerald-500 dark:group-hover:text-neutral-200">
                {link.description}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
