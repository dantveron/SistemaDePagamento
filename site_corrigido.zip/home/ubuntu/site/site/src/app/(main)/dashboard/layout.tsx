import { Sidebar } from "@/components/sidebars/sidebar";
import { Metadata } from "next";
import React from "react"
import { ThemeProvider } from "@/hooks/theme-provider";
import { Navbar } from "@/components/navbars/dashboard/navbar-dashboard";
/* import { NotVerifedAlert } from "@/components/cards/not-verfied";
 */
export const metadata: Metadata = {
  title: "Dashboard | ValoraPay",
  description: "Gerencie seus pagamentos, transações e saldo em tempo real com o painel da ValoraPay.",
  keywords: ["ValoraPay", "Dashboard de Pagamentos", "Gerenciar Transações", "Carteira Digital", "Financeiro"],
  authors: [{ name: "ValoraPay" }],
  openGraph: {
    title: "Dashboard | ValoraPay",
    description: "Visualize e controle suas movimentações financeiras com segurança.",
    url: "https://valorapay.com/dashboard",
    siteName: "ValoraPay",
    locale: "pt_BR",
    type: "website",
  }
};

export default function RootLayoutDashboard({
    children,
  }: Readonly<{
    children: React.ReactNode;
  }>) {
    return (
      <div className="flex w-full min-h-screen">
       {/*  <NotVerifedAlert /> */}
  <ThemeProvider
    attribute="class"
    defaultTheme="system"
    enableSystem
    disableTransitionOnChange
  >
    <Sidebar />
    <div className="flex-1">
      <Navbar/>
      <div>
        {children}
      </div>
    </div>
  </ThemeProvider>
</div>
    );
};