import { Navbar } from "@/components/navbars/navbar";

import { CheckoutSection } from "@/components/sections/checkout-section";
import { DashboardSection } from "@/components/sections/dashboard-section";
import { Footer } from "@/components/sections/footer";
import { HeroMainPage } from "@/components/sections/hero-home";
import { TaxSection } from "@/components/sections/taxa-section";

export default function Home() {
  return (
    <div className="flex flex-col w-full bg-black">
      <Navbar />
      <HeroMainPage />
      <DashboardSection />
      <TaxSection />
      <CheckoutSection />
      <Footer />
    </div>
  );
}
