import { authenticate } from "@/actions/api/authenticate";
import { NextRequest, NextResponse } from "next/server";

import { CreateClient } from "@/lib/appwrite";
import { ID } from "node-appwrite";
import { PixRequestSchema } from "@/schemas/pix-request";

const DATABASE_ID = process.env.DATABASE_ID!;
const COLLECTION_ID = process.env.COLLECTION_TRANSACTION!;

export async function POST(request: NextRequest) {
  const { databases } = await CreateClient();

  // Autenticação com client_id e client_secret
  const authResult = await authenticate(request);
  if (authResult instanceof NextResponse) return authResult;

  const userId = authResult.UserId;



  try {
    // Lê o corpo da requisição
    const body = await request.json();
    const validation = PixRequestSchema.safeParse(body);
    if (!validation.success) {
      return NextResponse.json({ error: "Dados inválidos", details: validation.error.flatten() }, { status: 400 });
    }

    const { amount, customer } = validation.data;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 3600 * 1000);

    // Busca a chave da EvoPay associada ao client_id no Appwrite
    const evoPayKey = process.env.TOKEN_EVOPAY!;

    // Chama a API da EvoPay com tratamento de redirecionamento
    const evoResponse = await fetch("https://pix.evopay.cash/v1/pix", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "API-Key": evoPayKey,
      },
      body: JSON.stringify({
        amount: amount / 100, // Converte centavos para reais
        callbackUrl: `https://valora.cash/api/v1/pixQrCode/callback`,
      }),
      redirect: "manual", // Permite seguir redirecionamentos
    });

    if (!evoResponse.ok) {
      const errorData = await evoResponse.json();
      console.error("Erro na API da EvoPay:", errorData);
      return NextResponse.json({ error: "Erro ao criar transação Pix", details: errorData }, { status: evoResponse.status });
    }

    const data = await evoResponse.json();

    if (!data?.id) {
      return NextResponse.json({ error: "Resposta inválida da API da EvoPay", details: data }, { status: 500 });
    }

    const transaction = {
      Id: ID.unique(),
      UserId: userId,
      txid: data.id,
      Amount: amount,
      Status: "PENDING",
      Payer: [/* {
        name: customer.name,
        emai: customer.email,
        document: customer.document
      } */],
      CreatedAt: now.toISOString(),
      UpdatedAt: now.toISOString(),
      ExpiresAt: expiresAt.toISOString(),
      Taxa: 2,
    };

    await databases.createDocument(DATABASE_ID, COLLECTION_ID, ID.unique(), transaction);

    return NextResponse.json({
      data: {
        txid: data.id,
        amount,
        status: "PENDING",
        pixCopiaECola: data.qrCodeText,
        pixCopiaEColaBase64: data.qrCodeBase64,
        platformFee: transaction.Taxa,
        createdAt: transaction.CreatedAt,
        updatedAt: transaction.UpdatedAt,
        expiresAt: transaction.ExpiresAt,
        customer: {
          name: customer.name ?? null,
          email: customer.email ?? null,
          document: customer.document ?? null
        }        
      },
    }, { status: 200 });

  } catch (err) {
    console.error("Erro ao criar transação Pix:", err);
    return NextResponse.json({ error: "Erro interno ao criar transação" }, { status: 500 });
  }
}