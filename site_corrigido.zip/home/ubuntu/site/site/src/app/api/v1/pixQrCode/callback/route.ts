import { Query } from "node-appwrite";
import { CreateClient } from "@/lib/appwrite";
import { NextResponse, NextRequest } from "next/server";


const DATABASE_ID = process.env.DATABASE_ID!;
const COLLECTION_ID = process.env.COLLECTION_TRANSACTION!; 

export async function POST(request: NextRequest) {
  try {
    const { databases } = await CreateClient();

    // Recebe dados do callback da EvoPay
    const body = await request.json();

    // Exemplo de dados que pode receber:
    // { id: "txid", status: "COMPLETED", amount: 12345, payerName: "João", ... }

    const txid = body.id;
    const statusEvo = body.status;

    if (!txid || !statusEvo) {
      return NextResponse.json({ error: "Dados inválidos no callback" }, { status: 400 });
    }

    // Mapeia status EvoPay para seu status interno
    let newStatus: "PENDING" | "PAID" | "FAILED" | "EXPIRED" | "REFUNDED" = "PENDING";

    switch (statusEvo) {
      case "COMPLETED":
        newStatus = "PAID";
        break;
      case "PENDING":
        newStatus = "PENDING";
        break;
      case "FAILED":
      case "CANCELLED":
        newStatus = "FAILED";
        break;
      default:
        newStatus = "FAILED";
    }

    // Busca a transação no banco e atualiza status
    const result = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_ID,
        [Query.equal("txid", txid)]
      );

    if (result.total === 0) {
      return NextResponse.json({ error: "Transação não encontrada" }, { status: 404 });
    }

    const transaction = result.documents[0];

    if (transaction.Status !== newStatus) {
      await databases.updateDocument(DATABASE_ID, COLLECTION_ID, transaction.$id, {
        Status: newStatus,
        UpdatedAt: new Date().toISOString(),
      });
    }

    // Responde 200 OK para EvoPay
    return NextResponse.json({ message: "Callback recebido com sucesso" }, { status: 200 });

  } catch (error) {
    console.error("Erro no callback EvoPay:", error);
    return NextResponse.json({ error: "Erro interno no callback" }, { status: 500 });
  }
}
