import { Query } from "node-appwrite";
import { authenticate } from "@/actions/api/authenticate";
import { CreateClient } from "@/lib/appwrite";
import { NextResponse, NextRequest } from "next/server";


const DATABASE_ID = process.env.DATABASE_ID!;
const COLLECTION_ID = process.env.COLLECTION_TRANSACTION!;

export async function GET(request: NextRequest) {
  const { databases } = await CreateClient();

  const AuthenticateRequest = await authenticate(request);
  if (AuthenticateRequest instanceof NextResponse) {
    return AuthenticateRequest;
  }


  const evoPayKey = process.env.TOKEN_EVOPAY!;


  const { searchParams } = new URL(request.url);
  const txid = searchParams.get("txid");

  if (!txid) {
    return NextResponse.json({ error: "txid is required" }, { status: 400 });
  }

  try {
    const result = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_ID,
      [Query.equal("txid", txid)]
    );

    if (result.total === 0) {
      return NextResponse.json({ error: "Transação não encontrada" }, { status: 404 });
    }

    const transaction = result.documents[0];

    // Faz requisição à EvoPay para checar status
    const evoResponse = await fetch(`https://pix.evopay.cash/v1/pix?id=${txid}`, {
      method: "GET",
      headers: {
        "API-Key": evoPayKey,
      },
    });

    if (!evoResponse.ok) {
      const error = await evoResponse.json();
      return NextResponse.json({ error: "Erro na API EvoPay", details: error }, { status: 500 });
    }

    const data = await evoResponse.json();
    const statusEvo = data.status;

    let newStatus: "PENDING" | "PAID" | "FAILED" | "EXPIRED" | "REFUNDED" = "PENDING";

    switch (statusEvo) {
      case "COMPLETED":
        newStatus = "PAID";
        break;
      case "PENDING":
        newStatus = new Date() > new Date(transaction.ExpiresAt) ? "EXPIRED" : "PENDING";
        break;
      case "FAILED":
      case "CANCELLED":
        newStatus = "FAILED";
        break;
      default:
        newStatus = "FAILED";
    }

    if (transaction.Status !== newStatus) {
      await databases.updateDocument(DATABASE_ID, COLLECTION_ID, transaction.$id, {
        Status: newStatus,
        UpdatedAt: new Date().toISOString(),
      });
    }

    return NextResponse.json(
      {
        status: newStatus,
        amount: transaction.Amount,
        expiresAt: transaction.ExpiresAt,
        updatedAt: transaction.UpdatedAt,
        txid: transaction.txid,
        payerName: data.payerName ?? null,
        payerCPF: data.payerCPF ?? null,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Erro ao verificar status Pix:", error);
    return NextResponse.json({ error: "Erro ao verificar transação Pix" }, { status: 500 });
  }
}
