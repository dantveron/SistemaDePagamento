import type { Metadata } from "next";
import "./globals.css";
import "@fontsource/inter-tight/400.css";  // Regular
import "@fontsource/inter-tight/700.css";  // Bold

export const metadata: Metadata = {
  title: "ValoraPay - Seu negócio, seu fluxo. Com Valora.",
  description:
    "Simplifique seus pagamentos online com a Valora. API fácil, suporte humanizado e integração com Pix, cartão e mais.",
  metadataBase: new URL("https://valora.cash"),
  openGraph: {
    title: "Valora - Seu negócio, seu fluxo. Com Valora.",
    description:
      "Simplifique seus pagamentos online com a Valora. API fácil, suporte humanizado e integração com Pix, cartão e mais.",
    url: "https://valora.cash",
    siteName: "Valora",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "ValoraPay - Seu negócio, seu fluxo. Com Valora.",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ValoraPay - Seu negócio, seu fluxo. Com ValoraPay.",
    description:
      "Simplifique seus pagamentos online com a ValoraPay. API fácil, suporte humanizado e integração com Pix, cartão e mais.",
    images: ["/og-image.png"],
    creator: "@valorabr",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <body
        style={{
          fontFamily: '"Inter Tight", sans-serif',
          WebkitFontSmoothing: "antialiased",
        }}
      >
        {children}
      </body>
    </html>
  );
}
