export type AvailableBalanceCardProps  = {
    SaldoDisponivel: number,
    SaldoBloqueado: number,
}

export type ReleaseBalanceCardProps = {
    SaldoBloqueado: number;
}