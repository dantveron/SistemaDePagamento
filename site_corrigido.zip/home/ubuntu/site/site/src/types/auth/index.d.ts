import {z} from "zod";
import { LoginSchema, RegisterSchemaStep1, RegisterSchemaStep2, RegisterSchemaStep3 } from "@/schemas/zod";

/** @description Types do Formulário de Registro */ 
export type Step1FormRegistro = z.infer<typeof RegisterSchemaStep1>;
export type Step2FormRegistro = z.infer<typeof RegisterSchemaStep2>;
export type Step3FormRegistro = z.infer<typeof RegisterSchemaStep3>;

/** @descrition Types do Formulário de Login */
export type LoginFormData = z.infer<typeof LoginSchema>;