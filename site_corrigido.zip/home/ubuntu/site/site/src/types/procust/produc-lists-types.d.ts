export type ProductListType = {
    Id: string;
    Titulo: string;
    Descricao: string;
    Price: number;
    Status: string;
    ProdutorId: string;
    Tipo: string;
    CreatedAt: string;
    Banner: string;
    CheckoutId: string;
}