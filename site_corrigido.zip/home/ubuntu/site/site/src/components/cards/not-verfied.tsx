export function NotVerifedAlert() {
    return (
      <div className="z-10 fixed inset-0 bg-black/50 backdrop-opacity-50 backdrop-blur-2xl flex items-center justify-center px-4">
        <div className="bg-neutral-900 rounded-xl p-6 max-w-md  z-10 w-full text-center">
          <h1 className="text-2xl font-semibold text-gray-50 mb-4">
            Bem-vindo, a Valora! 👋
          </h1>
          <p className="text-white/60 mb-6">
          Sua conta ainda não foi verificada para usar nosso gateway de pagamento. 
          Por favor, entre em contato com um de nossos gerentes para que ele possa 
          completar o seu cadastramento e liberar o acesso às transações.
          </p>
          <a
            href="https://wa.link/i3gvgh"
            className="bg-indigo-500 hover:bg-indigo-400 text-white font-semibold py-3 px-4 rounded-xl transition-colors duration-300">
            Falar com o Gerente
          </a>
        </div>
      </div>
    );
  }
  