"use client";

import { FaEdit, FaTrash, FaExternalLinkAlt } from "react-icons/fa";

interface Product {
  Id: string;
  Titulo: string;
  Descricao: string;
  Price: number;
  Status: string;
  ProdutorId: string;
  Tipo: string;
  CreatedAt: string;
  Banner: string;
  CheckoutId: string;
}

interface CardProducListProps {
  product: Product;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onCheckout: (checkoutId: string) => void;
}

export function CardProducList({ product, onEdit, onDelete, onCheckout }: CardProducListProps) {
  return (
    <div className="grid grid-cols-5 gap-2 p-2 border-b border-neutral-300 dark:border-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors">
      <span className="text-neutral-700 dark:text-neutral-300 truncate">{product.Id}</span>
      <span className="text-neutral-700 dark:text-neutral-300 truncate">{product.Titulo}</span>
      <span className="text-neutral-700 dark:text-neutral-300 truncate">{product.Tipo}</span>
      <span className="text-neutral-700 dark:text-neutral-300 truncate">{product.Status}</span>
      <div className="flex space-x-2">
        <button onClick={() => onEdit(product.Id)} className="text-blue-500 hover:text-blue-700">
          <FaEdit />
        </button>
        <button onClick={() => onDelete(product.Id)} className="text-red-500 hover:text-red-700">
          <FaTrash />
        </button>
        <button
          onClick={() => onCheckout(product.CheckoutId)}
          className="text-green-500 hover:text-green-700"
        >
          <FaExternalLinkAlt />
        </button>
      </div>
    </div>
  );
}