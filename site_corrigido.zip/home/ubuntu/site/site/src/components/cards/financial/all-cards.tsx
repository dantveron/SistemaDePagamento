"use server";
import { getWalletData } from "@/data/user/get-wallet";
import { AvilableBalanceCard } from "@/components/cards/financial/available-balance";
import { ReleaseBalance } from "@/components/cards/financial/release-balance";

export async function AllCards() {
  const wallet = await getWalletData();
  const data = wallet.data;

  return (
    <>
      {/* SALDO DISPONÍVEL */}
      <AvilableBalanceCard
        SaldoDisponivel={data?.SaldoDisponivel}
        SaldoBloqueado={data?.SaldoBloqueado}
      />

      {/* SALDO A LIBERAR */}
      <ReleaseBalance SaldoBloqueado={data?.SaldoBloqueado} />
    </>
  );
}
