import { FaRegHandPeace } from "react-icons/fa6";
import type { AvailableBalanceCardProps } from "@/types/data/balance-type";

export function AvilableBalanceCard({ SaldoDisponivel, SaldoBloqueado }: AvailableBalanceCardProps) {
    const saldoDisponivelNum = typeof SaldoDisponivel === "number" ? SaldoDisponivel : 0;
    const saldoBloqueadoNum = typeof SaldoBloqueado === "number" ? SaldoBloqueado : 0;
  
    const saldoTotal = parseFloat((saldoDisponivelNum + saldoBloqueadoNum).toFixed(2));
  
    const formatCurrency = (value: number) =>
      new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(value);
      
  return (
    <div className="bg-emerald-500 dark:bg-neutral-900 group rounded-2xl sm:rounded-3xl w-[390px] p-3 sm:px-4 sm:py-4 flex flex-col items-start justify-start border border-emerald-200 dark:border-neutral-700 hover:border-emerald-300 dark:hover:bg-neutral-800 transition-colors">
      <div className="flex items-start justify-start">
        <div className="bg-white border text-emerald-500 border-emerald-400 dark:bg-transparent dark:text-neutral-100 dark:border-neutral-600 p-1 rounded-md flex items-center justify-center mr-2 sm:mr-2">
          <FaRegHandPeace size={15} />
        </div>
        <div className="flex items-start justify-between w-full">
          <span className="text-black dark:text-neutral-100 tracking-tight text-lg font-semibold">
            Saldo Disponível
          </span>
        </div>
      </div>
      <h1 className="text-2xl text-white dark:text-neutral-100 tracking-tight font-bold">
        {formatCurrency(saldoTotal)}
      </h1>
    </div>
  );
}
