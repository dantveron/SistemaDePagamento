"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Edit, Trash2, ExternalLink, Loader2 } from "lucide-react"
import { getUserProducts } from "@/data/user/get-products"
import type { ProductListType } from "@/types/procust/produc-lists-types"

export function ListProducts() {
  const [products, setProducts] = useState<ProductListType[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const productsPerPage = 10

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true)
      const result = await getUserProducts()
      if (result.success && result.data) {
        setProducts(Array.isArray(result.data) ? result.data : [result.data])
      } else {
        setError(result.error || "Falha ao carregar produtos")
      }
      setLoading(false)
    }
    fetchProducts()
  }, [])

  // Lógica de paginação
  const indexOfLastProduct = currentPage * productsPerPage
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage
  const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct)
  const totalPages = Math.ceil(products.length / productsPerPage)

  // Handlers para ações
  const handleEdit = (id: string) => {
    console.log(`Editar produto com ID: ${id}`)
    window.open(`/dashboard/products/${id}`)
  }

  const handleDelete = (id: string) => {
    console.log(`Deletar produto com ID: ${id}`)
    // Lógica para deletar (ex.: chamada API)
  }

  const handleCheckout = (checkoutId: string) => {
    if (checkoutId) {
      window.open(`/checkout/v1/${checkoutId}`, "_blank")
    }
  }

  // Função para determinar a variante do badge baseado no status
  const getStatusBadge = (status: string) => {
    switch (status?.toLowerCase()) {
      case "ativo":
      case "active":
        return (
          <Badge variant="default" className="bg-green-500 hover:bg-green-600">
            Ativo
          </Badge>
        )
      case "inativo":
      case "inactive":
        return (
          <Badge variant="secondary" className="bg-red-500 hover:bg-red-600 text-white">
            Inativo
          </Badge>
        )
      case "pendente":
      case "pending":
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-600">
            Pendente
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <Card className="bg-neutral-100 dark:bg-neutral-800 border-neutral-300 dark:border-neutral-700">
        <CardHeader>
          <CardTitle className="text-neutral-800 dark:text-neutral-100">Lista de Produtos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-neutral-500" />
            <span className="ml-2 text-neutral-500">Carregando produtos...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="bg-neutral-100 dark:bg-neutral-800 border-neutral-300 dark:border-neutral-700">
        <CardContent className="pt-6">
          <div className="text-center py-8">
            <p className="text-red-500 font-medium">{error}</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (products.length === 0) {
    return (
      <Card className="bg-neutral-100 dark:bg-neutral-800 border-neutral-300 dark:border-neutral-700">
        <CardHeader>
          <CardTitle className="text-neutral-800 dark:text-neutral-100">Lista de Produtos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-neutral-600 dark:text-neutral-400">Você não tem nenhum produto ainda!</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-neutral-100 dark:bg-neutral-800 border-none">
      {/* <CardHeader>
        <CardTitle className="text-neutral-800 dark:text-neutral-100">Lista de Produtos</CardTitle>
        <p className="text-sm text-neutral-600 dark:text-neutral-400">
          {products.length} produto{products.length !== 1 ? "s" : ""} encontrado{products.length !== 1 ? "s" : ""}
        </p>
      </CardHeader> */}
      <CardContent>
        <Table>
          <TableHeader className="">
            <TableRow className="border-neutral-300 dark:border-neutral-600">
              <TableHead className="text-neutral-600 dark:text-neutral-400 font-medium">ID do Produto</TableHead>
              <TableHead className="text-neutral-600 dark:text-neutral-400 font-medium">Nome</TableHead>
              <TableHead className="text-neutral-600 dark:text-neutral-400 font-medium">Tipo</TableHead>
              <TableHead className="text-neutral-600 dark:text-neutral-400 font-medium">Status</TableHead>
              <TableHead className="text-neutral-600 dark:text-neutral-400 font-medium text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {currentProducts.map((product) => (
              <TableRow
                key={product.Id}
                className="border-neutral-200 dark:border-neutral-700 "
              >
                <TableCell className="font-mono text-sm text-neutral-700 dark:text-neutral-300">{product.Id}</TableCell>
                <TableCell className="font-medium text-neutral-800 dark:text-neutral-200">
                  {product.Titulo || "Nome não disponível"}
                </TableCell>
                <TableCell className="text-neutral-600 dark:text-neutral-400">
                  {product.Tipo || "Tipo não especificado"}
                </TableCell>
                <TableCell>{getStatusBadge(product.Status || "Indefinido")}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(product.Id)}
                      className="h-8 w-8 p-0 text-neutral-600 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(product.Id)}
                      className="h-8 w-8 p-0 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    {product.CheckoutId && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleCheckout(product.CheckoutId!)}
                        className="h-8 w-8 p-0 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* Paginação */}
        {totalPages > 1 && (
          <div className="mt-6">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    className={
                      currentPage === 1
                        ? "pointer-events-none opacity-50"
                        : "cursor-pointer text-neutral-600 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200"
                    }
                  />
                </PaginationItem>

                {/* Páginas */}
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const pageNumber = i + 1
                  if (totalPages <= 5) {
                    return (
                      <PaginationItem key={pageNumber}>
                        <PaginationLink
                          onClick={() => setCurrentPage(pageNumber)}
                          isActive={currentPage === pageNumber}
                          className="cursor-pointer"
                        >
                          {pageNumber}
                        </PaginationLink>
                      </PaginationItem>
                    )
                  }
                  return null
                })}

                {totalPages > 5 && <PaginationEllipsis />}

                <PaginationItem>
                  <PaginationNext
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    className={
                      currentPage === totalPages
                        ? "pointer-events-none opacity-50"
                        : "cursor-pointer text-neutral-600 hover:text-neutral-800 dark:text-neutral-400 dark:hover:text-neutral-200"
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>

            <p className="text-center text-sm text-neutral-500 dark:text-neutral-400 mt-2">
              Página {currentPage} de {totalPages} • {products.length} produtos no total
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

