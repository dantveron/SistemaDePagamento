"use client"

import { useEffect, useState } from "react"
import { Area, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { type ChartConfig, ChartContainer, ChartTooltipContent } from "@/components/ui/chart"
import { getTotalRevenueUser } from "@/data/user/total-revenue"
import { TrendingUp, TrendingDown } from "lucide-react"
import { RiLoader2Line } from "react-icons/ri";
const chartConfig = {
  revenue: {
    label: "Receita",
    color: "#6366f1", // indigo-500
  },
} satisfies ChartConfig

export function RevenueChart() {
  const [chartData, setChartData] = useState<{ name: string; revenue: number }[]>([])
  const [totalRevenue, setTotalRevenue] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchRevenue() {
      try {
        setLoading(true)
        const result = await getTotalRevenueUser()
        if (result.success) {
          const monthlyData = Object.entries(result.monthlyBreakdown).map(([month, revenue]) => ({
            name: month, // e.g., "2025-06"
            revenue,
          }))
          setChartData(monthlyData)
          setTotalRevenue(result.total)
        } else {
          setError(result.error || "Failed to fetch revenue data")
        }
      } catch (err) {
        setError("An error occurred while fetching revenue data")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchRevenue()
  }, [])

  if (loading) {
    return (
      <Card className="w-[550px] h-[507px] bg-neutral-800 border-neutral-700 border-none">
        <CardContent className="flex items-center justify-center h-full">
          <div className="flex items-center gap-2 text-neutral-400">
            <RiLoader2Line className="h-6 w-6 animate-spin" />
            <span>Carregando dados de receita...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className="w-[550px] h-[507px] bg-neutral-800 border-neutral-700 border-none">
        <CardContent className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-red-400 font-medium">{error}</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Calculate percentage change (simplified example, adjust based on actual data)
  const percentageChange =
    chartData.length > 1
      ? (((chartData[chartData.length - 1].revenue - chartData[0].revenue) / chartData[0].revenue) * 100).toFixed(1)
      : "0.0"

  const isPositive = Number.parseFloat(percentageChange) >= 0

  return (
    <Card className="w-[550px] h-[507px] bg-neutral-800  flex flex-col border-none">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 px-6 pt-6">
        <div className="space-y-2">
          <CardTitle className="text-xl font-semibold text-neutral-100">Receita Total</CardTitle>
          <CardDescription className="text-2xl font-bold text-neutral-100">
            {`R$ ${totalRevenue.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
          </CardDescription>
        </div>
        <div className="flex items-center gap-1 text-sm">
          {isPositive ? (
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          ) : (
            <TrendingDown className="w-4 h-4 text-red-400" />
          )}
          <span className={`font-medium ${isPositive ? "text-emerald-400" : "text-red-400"}`}>
            {Math.abs(Number.parseFloat(percentageChange))}%
          </span>
        </div>
      </CardHeader>
      <CardContent className="flex-1 px-6 pb-6">
        <ChartContainer config={chartConfig} className="h-full w-full">
          <AreaChart
            data={chartData}
            margin={{
              top: 20,
              right: 20,
              left: 20,
              bottom: 20,
            }}
          >
            <defs>
              <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="#404040" strokeDasharray="3 3" />
            <XAxis
              dataKey="name"
              stroke="#a3a3a3"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 12 }}
              tickMargin={10}
              tickFormatter={(value) => {
                const [month] = value.split("-")
                const monthNames = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
                return monthNames[Number.parseInt(month) - 1] || month
              }}
            />
            <YAxis
              stroke="#a3a3a3"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 12 }}
              tickMargin={10}
              tickFormatter={(value) => `R$ ${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip
              content={
                <ChartTooltipContent
                  className="bg-neutral-700 border-neutral-600 text-neutral-100 rounded-lg px-3 py-2"
                  labelClassName="text-neutral-300"
                  formatter={(value) => [
                    `R$ ${Number(value).toLocaleString("pt-BR", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}`,
                    "Receita",
                  ]}
                />
              }
              cursor={{ fill: "#404040", opacity: 0.3 }}
            />
            <Area
              type="monotone"
              dataKey="revenue"
              stroke="#6366f1"
              strokeWidth={2}
              fill="url(#revenueGradient)"
              fillOpacity={1}
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}

export default RevenueChart
