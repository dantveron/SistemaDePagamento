import {
  AlarmClock,
  MessageSquareMore,
  SquareStack,
  MonitorCheck,
  LayoutPanelTop,
  FileText,
  Italic,
  BadgePercent,
  Vote,
  LineChart,
  Vibrate,
  ShoppingCart,
} from "lucide-react";
import { MdOutlineImage, 
    MdOutlineOndemandVideo,
    MdOutlineTabletMac   } 
from "react-icons/md";

export function CheckoutSection() {
    return (    
        <section className="bg-white w-full min-h-screen mx-auto gap-y-[10px] flex flex-col items-center justify-center">
            <div className="flex flex-col items-center justify-center w-full max-w-lg">
                <div className="border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                    <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                        <ShoppingCart size={15} />
                    </div>
                    <span className="text-black tracking-tight font-medium">Checkout</span>
                </div>
                <div className="flex flex-col items-center gap-y-[20px]">
                    <h1 className="text-black text-center tracking-tight font-semibold text-[3rem] sm:text-[3.75rem] leading-[3rem] sm:leading-[3.5rem]">Construa seu <br />próprio checkout.</h1>
                    <p className="text-center text-sm sm:text-base text-black/60 font-semibold tracking-tight">Adicione modelos pré-definidos, ou crie seu próprio layout de checkout.</p>
                </div>
            </div>
            <div className="flex flex-col items-center gap-y-[10px] w-full">
                <div className="flex items-center gap-2">
                        <div className="border border-black/30 hover:-translate-y-2 ease-in-out transition-transform duration-150 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <MdOutlineImage size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Imagens</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <MdOutlineOndemandVideo size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Vídeos</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <LayoutPanelTop size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Layout Responsivo</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <AlarmClock size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Cronômetro</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <SquareStack size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Banners</span>
                        </div>
                </div>
                <div className="flex sm:hidden items-center gap-2">
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex sm:hidden items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <LayoutPanelTop size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Layout Responsivo</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex sm:hidden items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <FileText size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Listas</span>
                        </div>
                </div>
                <div className="flex sm:hidden items-center gap-2">
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex sm:hidden items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <Italic size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Textos</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex sm:hidden items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <Vote size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Vantagens</span>
                        </div>
                </div>
                <div className="flex items-center gap-2">
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <LineChart size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Indicador de Engajamento</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <FileText size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Listas</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <Italic size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Textos</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <BadgePercent size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Order Bump</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <Vote size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Vantagens</span>
                        </div>
                </div>
                <div className="flex items-center gap-2">
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <MessageSquareMore size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Depoimentos</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <MonitorCheck  size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Desktop</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 hidden sm:flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <MdOutlineTabletMac size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Tablet</span>
                        </div>
                        <div className="hover:-translate-y-2 ease-in-out transition-transform duration-150 border border-black/30 rounded-full px-4 py-2 flex items-center justify-center">
                            <div className="rounded-full border border-black/30 text-black flex items-center justify-center size-7 mr-1 ">
                                <Vibrate size={15} />
                            </div>
                            <span className="text-black tracking-tight font-medium">Mobile</span>
                        </div>
                </div>
            </div>
        </section>
    )
}