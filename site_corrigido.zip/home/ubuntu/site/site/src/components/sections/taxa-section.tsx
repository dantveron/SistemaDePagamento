import Link from "next/link";
import { MdDiscount, MdCheck } from "react-icons/md";
import { FaRegHandPeace } from "react-icons/fa6"
import { SymbolValora } from "../icons/valora";
import Image from "next/image";

export function TaxSection() {
    return (
        <section className="relative overflow-hidden flex items-center  flex-col w-full min-h-full justify-center">
            <div className="flex flex-col items-center gap-1 w-full mt-20 max-w-2xl mb-7">
                <div className="border border-white/30 rounded-full px-2 py-1 flex items-center justify-center">
                    <div className="rounded-full border border-white/30 text-white flex items-center justify-center size-7 mr-1 ">
                        <MdDiscount size={15} />
                    </div>
                    <span className="text-white tracking-tight font-medium">Taxas</span>
                </div>
                <h1 className="text-white text-center tracking-tight font-semibold text-[3rem] sm:text-[3.75rem] leading-[3rem] sm:leading-[3.5rem]">Traga seu negócio para a Valora</h1>
                <p className="text-center text-sm sm:text-base text-white/60 font-semibold tracking-tight">Automatize, escale e simplifique seu negócio em uma plataforma feita para quem quer vender mais com menos esforço.</p>
            </div>
            <div className="z-10 flex w-full items-center justify-center gap-x-[20px]">
                <div className="w-[390px] h-[490px] bg-white/50 border border-white/30 rounded-2xl p-2 flex flex-col items-center justify-center">
                    <div className="bg-white flex items-center flex-col p-4 justify-center rounded-2xl  w-full h-full ">
                        <div className="flex items-center gap-0.5 mb-2.5">
                            <SymbolValora className="fill-black w-[40px] h-[40px]" />
                            <span className=" text-3xl text-black tracking-tight font-semibold">Valora Pay</span>
                        </div>            
                        <h1 className="text-[1.5rem] text-black/60 font-semibold">Você só paga se vender</h1>
                        <div className="flex items-center gap-2">
                            <h1 className="text-[4rem] font-bold text-black">3.5%</h1>
                            <div className="rounded-xl bg-green-200 border border-green-300 flex items-center justify-center px-4 py-2">
                                <span className="font-bold text-green-500 text-md">+ R$ 0,00</span>
                            </div>
                        </div>
                        <div className="flex flex-col items-center-justify-start mb-3.5">
                            <span className="text-base text-black/60 font-semibold">Incluso:</span>
                            <div className="flex flex-col gap-2">
                                <div className="flex items-center gap-2 gap-x-[10px]">
                                    <div className="bg-green-500 rounded-lg flex item-center jusitfy-center p-1">
                                        <MdCheck size={17} className="text-white"/>
                                    </div>
                                    <p className="text-black/70 text-xs font-semibold text-start">Checkout e funis inteligentes: ordens adicionais, recuperação via WhatsApp/email.</p>
                                </div>
                                <div className="flex items-center gap-2 gap-x-[10px]">
                                    <div className="bg-green-500 rounded-lg flex item-center jusitfy-center p-1">
                                        <MdCheck size={17} className="text-white"/>
                                    </div>
                                    <p className="text-black/70 text-xs font-semibold text-start">Vendas automatizadas por API: Integração total com sistemas, bots e plataformas externas via API REST</p>
                                </div>
                                <div className="flex items-center gap-2 gap-x-[10px]">
                                    <div className="bg-green-500 rounded-lg flex item-center jusitfy-center p-1">
                                        <MdCheck size={17} className="text-white"/>
                                    </div>
                                    <p className="text-black/70 text-xs font-semibold text-start">Suporte humanizado: onboarding, live chat 24/7, equipe local com urgência.</p>
                                </div>
                                <div className="flex items-center gap-2 gap-x-[10px]">
                                    <div className="bg-green-500 rounded-lg flex item-center jusitfy-center p-1">
                                        <MdCheck size={17} className="text-white"/>
                                    </div>
                                    <p className="text-black/70 text-xs font-semibold text-start">E muito mais!</p>
                                </div>
                            </div>
                        </div>
                        <Link href={"/signup"} className="w-full bg-green-500 group borde border-green-600 hover:border-green-500 hover:bg-green-600 transition-all duration-200 easy-in-out rounded-xl min-h-14 flex items-center justify-center">
                            <FaRegHandPeace size={20} className="group-hover:rotate-45 text-white mr-2 transition-all ease-in-out duration-300" />
                            <span className="text-white text-md font-semibold">Começar agora!</span>
                        </Link>
                    </div>
                </div>
            </div>
            <div className="flex items-center justify-center mb-10 mt-10 rounded-xl px-2 py-1 border border-white bg-white/30 backdrop-blur-2xl">
                <span className="text-white">Alguma dúvida? <span className="text-white/60">Fale com um agante</span></span>
            </div>
            <div className="absolute inset-0 z-0">
                <div className="relative w-full h-full">
                <Image
                    src="/assets/background-pattern.png"
                    alt="Fundo decorativo"
                    fill
                    className="object-cover object-bottom opacity-30 mask-gradient"
                    priority
                />
                </div>
            </div>
        </section>
    )
}