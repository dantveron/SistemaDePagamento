"use client";
import { useState } from "react";
import { PlusIcon } from "lucide-react";
import { MdClose } from "react-icons/md";
import { CreateApiKeyForm } from "../forms/create-api-keys-form";

export function CreateApiKeyButton() {

    const [ isOpen, setIsOpen] = useState(false);

    return (
        <div className="realtive w-full">
            <div className="flex items-start justify-end">
                <button onClick={() => { setIsOpen(true) }} className="w-full max-w-[130px] sm:max-w-[260px] bg-indigo-500 hover:bg-indigo-400 cursor-pointer rounded-xl py-3 flex items-center justify-center">
                    <PlusIcon size={22} className="text-white dark:text-black mr-1 sm:mr-2" />
                    <span className="text-white font-medium tracking-tight ">Gerar Credenciais</span>
                </button>
            </div>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
                   <div className="bg-white dark:bg-neutral-900 p-6 flex flex-col rounded-3xl shadow-lg w-[90%] max-w-md">
                       <div className='w-full flex items-start justify-between'>
                           <div className='flex flex-col'>
                               <h2 className='text-xl text-black dark:text-white font-semibold'>
                                   Gerar Credenciais
                               </h2>
                           </div>
                           <button onClick={() => setIsOpen(false)} className='p-1 cursor-pointer hover:bg-black/10 dark:hover:bg-neutral-800 rounded-full transition-all ease-linear duration-150'>
                               <MdClose size={22} className='text-black dark:text-white' />
                           </button>
                       </div>
                       <CreateApiKeyForm />
                    </div>
                </div>
            )}
        </div>
    )
}