"use client"

import { Bar, BarChart, XAxis, YAxis } from "recharts"
import { MoreVertical } from "lucide-react"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { cn } from "@/lib/utils"

// Dados simulados para o gráfico com métodos de pagamento
const data = [
  { time: "10 min atrás", pix: 300, cartao: 150, boleto: 250 },
  { time: "9 min atrás", pix: 200, cartao: 180, boleto: 120 },
  { time: "8 min atrás", pix: 250, cartao: 200, boleto: 30 },
  { time: "7 min atrás", pix: 180, cartao: 150, boleto: 70 },
  { time: "6 min atrás", pix: 200, cartao: 258, boleto: 260 },
  { time: "5 min atrás", pix: 220, cartao: 300, boleto: 280 },
  { time: "4 min atrás", pix: 180, cartao: 250, boleto: 100 },
  { time: "3 min atrás", pix: 250, cartao: 220, boleto: 180 },
  { time: "2 min atrás", pix: 150, cartao: 120, boleto: 50 },
  { time: "Agora", pix: 200, cartao: 150, boleto: 100 },
]

// Componente de métrica
interface MetricProps {
  value: string
  label: string
  color: string
}

function Metric({ value, label, color }: MetricProps) {
  return (
    <div className="flex flex-col items-center">
      <p className="text-lg font-bold">{value}</p>
      <div className={cn("mb-0.5 mt-1 h-1.5 w-8 rounded-full", color)} />
      <p className="text-center text-xs text-gray-600">{label}</p>
    </div>
  )
}

export function TypeOfSalesChartLandingPage() {
  const chartConfig = {
    pix: {
      label: "Pix",
      color: "oklch(70.7% 0.165 254.624)",
    },
    cartao: {
      label: "Cartão",
      color: "oklch(71.4% 0.203 305.504)",
    },
    boleto: {
      label: "Boleto",
      color: "oklch(79.2% 0.209 151.711)",
    },
  }

  return (
    <div className="rounded-xl bg-white w-full max-w-[350px] h-[344px] border border-blue-400/50 p-6 flex overflow-hidden flex-col items-start justify-start">
      <div className="flex items-center justify-between w-full mb-2">
        <span className="text-black text-xl tracking-tight font-medium">Tipo de Vendas</span>
        <MoreVertical size={22} className="text-black mr-2.5" />
      </div>

      {/* Gráfico ajustado para o espaço disponível */}
      <div className="w-full" style={{ height: "calc(100% - 100px)" }}>
        <ChartContainer config={chartConfig} className="h-full">
          <BarChart accessibilityLayer data={data} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
            <XAxis
              dataKey="time"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
              tickFormatter={(value) => {
                return value === "10 min atrás" || value === "Agora" ? value : ""
              }}
            />
            <YAxis hide domain={[0, 1000]} />
            <ChartTooltip content={<ChartTooltipContent />} cursor={false} />
            <Bar dataKey="pix" stackId="a" fill="var(--color-pix)" radius={[0, 0, 0, 0]} />
            <Bar dataKey="cartao" stackId="a" fill="var(--color-cartao)" radius={[0, 0, 0, 0]} />
            <Bar dataKey="boleto" stackId="a" fill="var(--color-boleto)" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </div>

      {/* Métricas de pagamento */}
      <div className="mt-2 flex justify-between w-full px-1">
        <Metric value="1,5K" label="Pix" color="bg-blue-400" />
        <Metric value="980" label="Cartão" color="bg-purple-400" />
        <Metric value="750" label="Boleto" color="bg-green-400" />
      </div>
    </div>
  )
}
