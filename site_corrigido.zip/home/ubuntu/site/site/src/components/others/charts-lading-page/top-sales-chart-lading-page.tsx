"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis, TooltipProps } from "recharts"
import { MoreVertical, TrendingUp } from "lucide-react"
import { ChartContainer, ChartTooltip } from "@/components/ui/chart"

// Gerar dados simulados para o gráfico
const generateData = () => {
  const data = []
  const hoursInDay = 24
  const pointsPerHour = 2 // 30 minutos de intervalo para reduzir a densidade de pontos
  const totalPoints = hoursInDay * pointsPerHour

  for (let i = 0; i < totalPoints; i++) {
    const hour = Math.floor(i / pointsPerHour)
    const minute = (i % pointsPerHour) * 30
    const timeString = `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`

    // Criar um padrão de valores que se assemelha ao gráfico da imagem
    let value = 30 + Math.sin(i / 5) * 20 + Math.random() * 10

    // Adicionar alguns picos específicos
    if (i === 19) value = 70 // Pico por volta das 09:30

    data.push({
      time: timeString,
      receita: Math.round(value),
      fullTime: `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`,
      formattedTime: hour % 12 === 0 ? (hour === 0 ? "00:00" : "12:00") : hour === 23 && minute === 30 ? "23:59" : "",
    })
  }

  return data
}

const data = generateData()

const CustomTooltipContent = ({
  active,
  payload,
}: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    const value = payload[0]?.value as number;

    return (
      <div className="rounded-md bg-gray-900 p-2 text-white shadow-lg text-xs">
        <p className="mb-0.5 font-semibold">
          Hoje, {payload[0]?.payload.fullTime}
        </p>
        <p className="font-semibold">
          R$ {(value * 1000).toLocaleString("pt-BR", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          })} (+56)
        </p>
      </div>
    );
  }
  return null;
};

export function TotalRevenueChartLandingPage() {
  const chartConfig = {
    receita: {
      label: "Receita",
      color: "hsl(var(--chart-1))",
    },
  }

  return (
    <div className="rounded-xl bg-white w-full max-w-[350px] h-[344px] border border-blue-400/50 p-6 flex overflow-hidden flex-col items-start justify-start">
      <div className="flex items-center justify-between w-full mb-2">
        <span className="text-black text-xl tracking-tight font-medium">Receita Total</span>
        <MoreVertical size={22} className="text-black mr-2.5" />
      </div>

      {/* Valor e crescimento */}
      <div className="flex items-end justify-between w-full mb-4">
        <h2 className="text-2xl font-bold">R$ 37.045,25</h2>
        <div className="flex items-center text-xs font-medium text-blue-600">
          <TrendingUp className="mr-0.5 h-3 w-3" />
          2,0%
        </div>
      </div>

      {/* ChartContainer ajustado para o espaço disponível */}
      <div className="w-full flex-grow" style={{ height: "calc(100% - 80px)" }}>
        <ChartContainer config={chartConfig} className="h-full">
          <AreaChart accessibilityLayer data={data} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="fillReceita" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-receita)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="var(--color-receita)" stopOpacity={0.05} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="#f5f5f5" strokeDasharray="3 3" />
            <XAxis
              dataKey="formattedTime"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
              padding={{ left: 0, right: 0 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
            />
            <ChartTooltip content={<CustomTooltipContent />} cursor={false} />
            <Area
              type="monotone"
              dataKey="receita"
              stroke="var(--color-receita)"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#fillReceita)"
              dot={false}
            />
          </AreaChart>
        </ChartContainer>
      </div>
    </div>
  )
}
