export function EditProdutcNavbar() {
    return (
        <div className="bg-neutral-800 w-full py-2.5 px-5 rounded-full">
            {/* Container que faz o scroll nas telas pequenas */}
            <div className="flex sm:grid sm:grid-cols-4 gap-5 overflow-x-auto sm:overflow-x-visible scroll-hidden">
                <button className="flex-none px-3 py-2 text-sm sm:text-base sm:px-4 sm:py-3 rounded-full dark:bg-neutral-700 hover:bg-neutral-700 text-white font-semibold">
                    Configurações
                </button>
                <button className="flex-none px-3 py-2 text-sm sm:text-base sm:px-4 sm:py-3 rounded-full dark:bg-neutral-700 hover:bg-neutral-700 text-white font-semibold">
                    Checkout
                </button>
                <button className="flex-none px-3 py-2 text-sm sm:text-base sm:px-4 sm:py-3 rounded-full dark:bg-neutral-700 hover:bg-neutral-700 text-white font-semibold">
                    Upsell e order bump
                </button>
                <button className="flex-none px-3 py-2 sm:px-4 sm:py-3 rounded-full dark:bg-neutral-700 hover:bg-neutral-700 text-white font-semibold">
                    <span className="truncate text-sm sm:text-base">Co-Produção</span>
                </button>
            </div>
        </div>
    )
}
