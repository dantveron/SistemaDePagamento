"use client";

import { usePathname } from "next/navigation";

const LinksMap = [
  { name: "Dashboard", path: "/dashboard" },
  { name: "Produtos", path: "/dashboard/products" },
  { name: "Vendas", path: "/dashboard/sales" },
  { name: "Financeiro", path: "/dashboard/financial" },
  { name: "Relatórios", path: "/dashboard/reports" },
  { name: "Integrações", path: "/dashboard/integrations" },
]

export function LeftNavbarDashboard() {
  const pathname = usePathname();
  const current = LinksMap.find((item) => item.path === pathname);

  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-4 w-full">
      <span className="text-2xl sm:text-3xl font-semibold text-black dark:text-white tracking-tight">
        {current ? current.name : ""}
      </span>
    </div>
  );
}
