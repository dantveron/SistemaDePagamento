import { HiOutlineBell } from "react-icons/hi";
import { PegarUsuarioLogado } from "@/lib/appwrite";
import { DropDown } from "@/components/others/drop-down";
import { LeftNavbarDashboard } from "./left";

export async function Navbar() {
    const user = await PegarUsuarioLogado();

    return (
        <header className="w-full bg-neutral-900 flex items-start sm:items-center justify-between gap-4 p-4">
        {/* Título + Filtros */}
        <LeftNavbarDashboard />
      
        {/* Ações (botões) */}
        <div className="flex items-center gap-3 sm:gap-4 self-end sm:self-auto">
          <button className="size-12 rounded-full hover:bg-black/10 dark:hover:bg-white/10 flex items-center justify-center text-black/60 dark:text-white/60 hover:text-black/80 dark:hover:text-white/80 transition-colors duration-300">
            <HiOutlineBell size={20} />
          </button>
          <DropDown user={user} />
        </div>
      </header>
      
    )
}