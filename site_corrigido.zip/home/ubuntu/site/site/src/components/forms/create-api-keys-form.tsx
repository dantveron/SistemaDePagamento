"use client";
import { useState, FormEvent, useTransition } from "react";
import { generateCredentials } from "@/actions/api/gerentate-credentials";

export function CreateApiKeyForm() {
    const [, startTransition] = useTransition();
    const [ name, setName ] = useState("");
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        const formData = new FormData(e.target as HTMLFormElement);

        const result = await generateCredentials(formData);
        if (result.success) {
            startTransition(() => {
                window.location.reload();
            });
        } else {
            console.error("Failed to create credentials:", result.error);
         
        }
    };
    return (
        <form onSubmit={handleSubmit} className="flex flex-col gap-1 items-start w-full">
            <div className="flex flex-col gap-1 w-full">
                <label htmlFor="name" className='text-black dark:text-white'>Nome das Credenciais</label>
                <div className="relative flex w-full border border-black/30 dark:border-white/30 rounded-2xl py-[10px]">
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="focus:outline-none ml-4 w-full text-black dark:text-white "
                        placeholder="Ex: Produto"
                    />
                </div>
            </div>
            <button
                type="submit"
                className="mt-2 w-full max-w-md rounded-2xl py-[12px] bg-indigo-500 flex items-center justify-center"
            >
                <span className="text-white">Criar Produto</span>
            </button>
        </form>
    )
}