// src/components/forms/EditProductForm.tsx
"use client";

import React from "react";
import { PlusCircle } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface EditProductFormProps {
  product: {
    title: string;
    description: string;
    price: number;
    banner: string;
    onChange: (update: Partial<{
      title: string;
      description: string;
      price: number;
      banner: string;
    }>) => void;
  };
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  bannerFile: File | null;
  error: string | null;
}

export function EditProductForm({ 
  product, 
  onSubmit, 
  onFileChange, 
  bannerFile, 
  error 
}: EditProductFormProps) {
  return (
    <Card className="w-full border-none p-4 mt-5 bg-neutral-800 rounded-2xl ">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">
          Configurações do Produto
        </CardTitle>
        <CardDescription className="text-base">
          Personalize as informações principais do seu Produto.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-5 p-2">
          <div className="space-y-2">
            <Label htmlFor="title">Título *</Label>
            <Input
              id="title"
              value={product.title}
              onChange={(e) =>
                product.onChange({ title: e.target.value })
              }
              className="rounded-xl text-base bg-neutral-900 border-none py-7 px-4"
              placeholder="Informe o título"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="price">Preço *</Label>

            <Input
              id="price"
              type="number"
              value={product.price}
              onChange={(e) =>
                product.onChange({ price: parseFloat(e.target.value) })
              }
              className="rounded-xl text-base bg-neutral-900 border-none py-7 px-4"
              placeholder="Informe o preço"
              step="0.01"
              required
            />
          </div> 


          <div className="space-y-2">
            <Label htmlFor="description">Descrição *</Label>
            <Textarea
              id="description"
              value={product.description}
              onChange={(e) =>
                product.onChange({ description: e.target.value })
              }
              className="border-none bg-neutral-900 h-[198px] rounded-xl"
              placeholder="Informe a descrição"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="banner">Banner *</Label>
            <div className="border-2 items-center justify-center flex flex-col border-dashed border-neutral-600 bg-neutral-700 rounded-lg h-[198px] p-4 text-center">
              <input
                id="banner"
                type="file"
                accept="image/png, image/jpeg"
                onChange={onFileChange}
                className="hidden"
              />
              <div className="flex flex-col items-center gap-2">
                <PlusCircle size={25} className="text-indigo-500" />
                <button
                    type="button"
                    onClick={() =>
                        document.getElementById("banner")?.click()
                    }
                    className="mb-2 bg-none text-indigo-500 flex flex-col gap-1 rounded-lg drop-shadow-none font-semibold">
                    <span>Selecione do computador</span>
                    <span className="text-black dark:text-gray-400">
                    ou arraste
                    </span>
                </button>
              </div>
              {bannerFile ? (
                <p>Arquivo escolhido: {bannerFile.name}</p>
              ) : product.banner ? (
                <p>Imagem atual: {product.banner.split('/').pop()}</p>
              ) : (
                <p className="text-black dark:text-gray-400 font-light">
                    png ou jpg, tamanho máximo: 5Mb, dimensão mínima de 140px x 140px.
                </p>
              )}

            </div>
          </div>

          {error && <p className="text-red-500 mt-4">{error}</p>}

          <div className="flex items-center justify-between w-full">
            <button
              type="submit"
              className="w-full max-w-[200px] drop-shadow-none shadow-none py-[15px] cursor-pointer rounded-xl bg-indigo-500 hover:bg-indigo-400 flex items-center justify-center">
              <span className="font-semibold text-gray-50">Salvar</span>
            </button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

