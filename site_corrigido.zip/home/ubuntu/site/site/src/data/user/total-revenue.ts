"use server";
import { PegarUsuarioLogado, CreateClient } from "@/lib/appwrite";
import { Query } from "node-appwrite";

export async function getTotalRevenueUser() {
    const { databases } = await CreateClient();
    const userLogged = await PegarUsuarioLogado();

    if (!userLogged || !userLogged.$id) {
        return {
            success: false,
            error: "Usuário não autenticado ou ID inválido",
            total: 0,
            monthlyBreakdown: {},
        };
    }

    const vendas = await databases.listDocuments(
        process.env.DATABASE_ID!,
        process.env.COLLECTION_TRANSACTION!,
        [Query.equal("UserId", userLogged.$id)]
    );

    const monthlyBreakdown = vendas.documents.reduce((acc, transaction) => {
        const createdAt = new Date(transaction.$createdAt);
        const monthYear = `${createdAt.getFullYear()}-${String(createdAt.getMonth() + 1).padStart(2, '0')}`; // e.g., "2025-06"
        const value = typeof transaction.value === "number" ? transaction.value : 0;

        acc[monthYear] = (acc[monthYear] || 0) + value;
        return acc;
    }, {} as { [key: string]: number });

    const totalRevenue = Object.values(monthlyBreakdown).reduce((sum, value) => sum + value, 0);

    return {
        success: true,
        total: totalRevenue,
        monthlyBreakdown,
        error: null,
    };
}