"use server";
import { CreateClient } from "@/lib/appwrite";
import { Query } from "node-appwrite";

export async function getProductData(id: string) {
    try {
        const { databases } = await CreateClient();
        const databaseId = process.env.DATABASE_ID;
        const collectionId = process.env.PRODUCT_COLLECTION;

        if (!databaseId || !collectionId) {
            throw new Error("Database ID or Collection ID is not defined in environment variables");
        }

        const response = await databases.listDocuments(databaseId, collectionId, [
            Query.equal("Id", id),
            Query.limit(1), // Limit to 1 document since we're fetching by ID
        ]);

        if (response.documents.length === 0) {
            throw new Error("Product not found");
        }

        const product = response.documents[0];
        return {
            title: product.Titulo ?? "",
            description: product.Descricao ?? "",
            price: product.Price ?? 0,
            banner: product.Banner ?? "", // Banner é o nome correto
        };
    } catch (error) {
        console.error("Error fetching product data:", error);
        throw new Error("Failed to fetch product data");
    }
}