"use server";

import { CreateClient, PegarUsuarioLogado } from "@/lib/appwrite";
import { Query } from "node-appwrite";

export async function getBestProdutcs() {
  try {
    const { databases } = await CreateClient();
    const userLogged = await PegarUsuarioLogado();

    if (!userLogged || !userLogged.$id) {
      return {
        success: false,
        error: "Usuário não autenticado ou ID inválido",
      };
    }

    /* const offset = (page - 1) * limit; */
    const productsResponse = await databases.listDocuments(
      process.env.DATABASE_ID!,
      process.env.PRODUCT_COLLECTION!,
      [Query.equal("ProdutorId", userLogged.$id)],
    );

    if (productsResponse.documents.length === 0) {
      return {
        success: false,
        error: "Nenhum produto encontrado para o usuário",
      };
    }

    const products = productsResponse.documents.map((doc) => ({
      Id: doc.Id,
      Titulo: doc.Titulo,
      Descricao: doc.Descricao,
      Price: doc.Price,
      Status: doc.Status,
      ProdutorId: doc.ProdutorId,
      Tipo: doc.Tipo,
      CreatedAt: doc.CreatedAt,
      Banner: doc.Banner,
      CheckoutId: doc.CheckoutId,
    }));

    return {
      success: true,
      data: products,
      total: productsResponse.total, // Total de produtos para paginação
    };
  } catch (error) {
    console.log("Erro ao buscar produtos do usuário", error);
    return {
      success: false,
      error: "Falha ao buscar produtos do usuário",
    };
  }
}