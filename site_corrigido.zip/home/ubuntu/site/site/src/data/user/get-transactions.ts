import "server-only";
import { CreateClient, PegarUsuarioLogado } from "@/lib/appwrite";
import { Query } from "node-appwrite";

export async function getUserTransactions() {
    try {
        const { databases } = await CreateClient();
        const userLogged = await PegarUsuarioLogado();
    
        if (!userLogged || !userLogged.$id) return {
            success: false,
            error: "Usuário não authenticado ou ID inválido"
        };

        const products = await databases.listDocuments(
            process.env.DATABASE_ID!,
            process.env.COLLECTION_TRANSACTION!,
            [Query.equal("UserId", userLogged.$id)]
        )
    
        return {
            success: true,
            data: products.documents
        };   
    } catch (error) {
        console.log("Erro ao buscar transações do usuário", error);
        return {
        success: false,
        error: "Falha ao buscar transações do usuário",
        };
    }
}