"use server";

import { CreateClient, PegarUsuarioLogado } from "@/lib/appwrite";
import { Query } from "node-appwrite";

export async function getWalletData() {
  try {
    const { databases } = await CreateClient();
    const user = await PegarUsuarioLogado();

    if (!user || !user.$id) {
      return {
        success: false,
        error: "Usuário não autenticado ou ID inválido",
      };
    }

    const walletResponse = await databases.listDocuments(
      process.env.DATABASE_ID!,
      process.env.WALLET_COLLECTION!,
      [Query.equal("UserId", user.$id)]
    );

    if (walletResponse.documents.length === 0) {
      return {
        success: false,
        error: "Nenhum dado de carteira encontrado para o usuário",
      };
    }

    const wallet = walletResponse.documents[0];

    return {
      success: true,
      data: {
        SaldoDisponivel: wallet.SaldoDisponivel,
        SaldoBloqueado: wallet.SaldoBloqueado,
      },
    };
  } catch (error) {
    console.log("Erro ao buscar dados da carteira", error);
    return {
      success: false,
      error: "Falha ao buscar dados da carteira",
    };
  }
}