# Prompt Corrigido e Melhorado para o Projeto Admin Dashboard

## Análise do Problema Original

O erro `Module not found: Error: Can't resolve '@heroicons/react/24/outline'` indica que o projeto está tentando importar ícones do pacote `@heroicons/react`, mas este pacote não está instalado nas dependências do projeto.

### Diagnóstico Completo

1. **Projeto**: Admin Dashboard Next.js 15.3.3 com React 19
2. **Gerenciador de Pacotes**: Bun (para desenvolvimento) e npm/yarn (para build)
3. **Framework**: Next.js com TypeScript e Tailwind CSS
4. **Problema**: Dependência `@heroicons/react` não instalada
5. **Solução**: O projeto já possui `react-icons` e `lucide-react` instalados

## Soluções Recomendadas

### Opção 1: Usar React Icons (Recomendado)
O projeto já possui `react-icons` instalado. Para usar ícones do Heroicons através do react-icons:

```bash
# Não é necessário instalar nada adicional
```

```javascript
// Importação correta usando react-icons
import { HiOutlineSearch, HiOutlineMenu } from 'react-icons/hi2';
// ou para versão v1
import { HiOutlineSearch, HiOutlineMenu } from 'react-icons/hi';

// Uso no componente
function SearchComponent() {
  return (
    <div>
      <HiOutlineSearch className="w-6 h-6" />
      <HiOutlineMenu className="w-6 h-6" />
    </div>
  );
}
```

### Opção 2: Usar Lucide React (Alternativa Moderna)
O projeto já possui `lucide-react` instalado, que é uma biblioteca moderna e bem mantida:

```javascript
// Importação usando lucide-react
import { Search, Menu, User, Settings } from 'lucide-react';

// Uso no componente
function NavigationComponent() {
  return (
    <div>
      <Search className="w-6 h-6" />
      <Menu className="w-6 h-6" />
      <User className="w-6 h-6" />
      <Settings className="w-6 h-6" />
    </div>
  );
}
```

### Opção 3: Instalar @heroicons/react (Se Necessário)
Se for absolutamente necessário usar o pacote oficial do Heroicons:

```bash
# Usando npm
npm install @heroicons/react

# Usando yarn
yarn add @heroicons/react

# Usando bun
bun add @heroicons/react
```

```javascript
// Importação correta do @heroicons/react
import { MagnifyingGlassIcon, Bars3Icon } from '@heroicons/react/24/outline';
import { MagnifyingGlassIcon as MagnifyingGlassIconSolid } from '@heroicons/react/24/solid';

// Uso no componente
function SearchComponent() {
  return (
    <div>
      <MagnifyingGlassIcon className="w-6 h-6" />
      <Bars3Icon className="w-6 h-6" />
    </div>
  );
}
```

## Package.json Otimizado

```json
{
  "name": "admin-dashboard",
  "version": "0.1.0",
  "private": true,
  "main": "index.js",
  "scripts": {
    "dev": "bun --hot next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "type-check": "tsc --noEmit",
    "clean": "rm -rf .next out node_modules/.cache"
  },
  "dependencies": {
    "@arcjet/inspect": "^1.0.0-beta.8",
    "@arcjet/next": "^1.0.0-beta.8",
    "@fontsource/inter-tight": "^5.2.6",
    "@hookform/resolvers": "^5.0.1",
    "@radix-ui/react-label": "^2.1.7",
    "@radix-ui/react-select": "^2.2.5",
    "@radix-ui/react-slot": "^1.2.3",
    "aos": "^2.3.4",
    "appwrite": "^18.1.1",
    "bcryptjs": "^3.0.2",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "framer-motion": "^12.16.0",
    "lucide-react": "^0.515.0",
    "motion": "^12.16.0",
    "next": "15.3.3",
    "next-sitemap": "^4.2.3",
    "next-themes": "^0.4.6",
    "node-appwrite": "^17.0.0",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-hook-form": "^7.57.0",
    "react-icons": "^5.5.0",
    "recharts": "^2.15.3",
    "resend": "^4.5.2",
    "tailwind-merge": "^3.3.1",
    "tailwindcss": "^4.1.8",
    "zod": "^3.25.51"
  },
  "devDependencies": {
    "@eslint/eslintrc": "^3.1.0",
    "@tailwindcss/postcss": "^4.0.0",
    "@types/node": "^20.11.19",
    "@types/react": "^19.0.15",
    "@types/react-dom": "^19.0.11",
    "eslint": "^9.0.0",
    "eslint-config-next": "15.3.3",
    "tw-animate-css": "^1.3.4",
    "typescript": "^5.4.5"
  },
  "engines": {
    "node": ">=18.0.0",
    "npm": ">=8.0.0"
  }
}
```

## Melhores Práticas Implementadas

### 1. Gerenciamento de Dependências
- **Evitar duplicação**: Use apenas uma biblioteca de ícones por projeto
- **Preferir bibliotecas bem mantidas**: `lucide-react` é mais moderno que `react-icons`
- **Versionamento específico**: Use versões específicas para evitar quebras

### 2. Estrutura de Importação
```javascript
// ❌ Evitar - importação incorreta
import { SearchIcon } from '@heroicons/react/outline';

// ✅ Correto - usando react-icons
import { HiOutlineSearch } from 'react-icons/hi2';

// ✅ Melhor - usando lucide-react
import { Search } from 'lucide-react';
```

### 3. Otimização de Performance
```javascript
// ✅ Tree-shaking otimizado
import { Search, Menu } from 'lucide-react';

// ❌ Evitar - importa toda a biblioteca
import * as Icons from 'lucide-react';
```

### 4. Componente de Ícone Reutilizável
```typescript
// components/ui/icon.tsx
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface IconProps {
  icon: LucideIcon;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function Icon({ icon: IconComponent, size = 'md', className }: IconProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  return (
    <IconComponent 
      className={cn(sizeClasses[size], className)} 
    />
  );
}

// Uso
import { Search } from 'lucide-react';
import { Icon } from '@/components/ui/icon';

<Icon icon={Search} size="lg" className="text-blue-500" />
```

## Comandos de Correção Imediata

### Para corrigir o erro atual:

1. **Opção Rápida** - Substituir importações:
```bash
# Buscar e substituir todas as importações incorretas
find src -name "*.tsx" -o -name "*.ts" | xargs sed -i 's/@heroicons\/react\/24\/outline/lucide-react/g'
```

2. **Instalar dependência faltante** (se necessário):
```bash
bun add @heroicons/react
```

3. **Limpar cache e reinstalar**:
```bash
rm -rf node_modules .next
bun install
bun run build
```

## Estrutura de Projeto Otimizada

```
src/
├── components/
│   ├── ui/           # Componentes base (shadcn/ui)
│   ├── icons/        # Componentes de ícones customizados
│   ├── forms/        # Componentes de formulário
│   ├── charts/       # Componentes de gráficos
│   └── layout/       # Componentes de layout
├── lib/
│   ├── utils.ts      # Utilitários gerais
│   ├── constants.ts  # Constantes da aplicação
│   └── types.ts      # Tipos TypeScript
├── hooks/            # Custom hooks
├── app/              # App Router (Next.js 13+)
└── styles/           # Estilos globais
```

## Scripts de Build Otimizados

```json
{
  "scripts": {
    "dev": "bun --hot next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint --fix",
    "type-check": "tsc --noEmit",
    "analyze": "ANALYZE=true next build",
    "clean": "rm -rf .next out node_modules/.cache",
    "test": "jest",
    "test:watch": "jest --watch"
  }
}
```

## Configuração de Performance

### next.config.ts otimizado:
```typescript
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    optimizePackageImports: ['lucide-react', 'react-icons'],
  },
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production',
  },
  images: {
    formats: ['image/webp', 'image/avif'],
  },
  webpack: (config) => {
    config.optimization.splitChunks = {
      chunks: 'all',
      cacheGroups: {
        icons: {
          test: /[\\/]node_modules[\\/](lucide-react|react-icons)[\\/]/,
          name: 'icons',
          chunks: 'all',
        },
      },
    };
    return config;
  },
};

export default nextConfig;
```

## Resumo das Melhorias

1. **Correção do erro principal**: Substituição de `@heroicons/react` por `lucide-react`
2. **Otimização de dependências**: Remoção de bibliotecas duplicadas
3. **Melhoria de performance**: Tree-shaking e code splitting
4. **Estrutura de projeto**: Organização mais clara e escalável
5. **TypeScript**: Tipagem melhorada para ícones
6. **Build otimizado**: Configurações de performance para produção

Este prompt corrigido resolve o erro original e implementa as melhores práticas modernas para desenvolvimento web com Next.js e React.



## Exemplos Práticos de Migração

### Migração de Importações Heroicons para Lucide React

#### Antes (com erro):
```typescript
// ❌ Causa erro: Module not found
import { 
  MagnifyingGlassIcon,
  Bars3Icon,
  UserIcon,
  CogIcon 
} from '@heroicons/react/24/outline';

function Navbar() {
  return (
    <nav className="flex items-center gap-4">
      <MagnifyingGlassIcon className="w-6 h-6" />
      <Bars3Icon className="w-6 h-6" />
      <UserIcon className="w-6 h-6" />
      <CogIcon className="w-6 h-6" />
    </nav>
  );
}
```

#### Depois (corrigido):
```typescript
// ✅ Funciona perfeitamente
import { 
  Search,
  Menu,
  User,
  Settings 
} from 'lucide-react';

function Navbar() {
  return (
    <nav className="flex items-center gap-4">
      <Search className="w-6 h-6" />
      <Menu className="w-6 h-6" />
      <User className="w-6 h-6" />
      <Settings className="w-6 h-6" />
    </nav>
  );
}
```

### Tabela de Equivalência de Ícones

| Heroicons | Lucide React | Descrição |
|-----------|--------------|-----------|
| `MagnifyingGlassIcon` | `Search` | Ícone de busca |
| `Bars3Icon` | `Menu` | Menu hambúrguer |
| `UserIcon` | `User` | Ícone de usuário |
| `CogIcon` | `Settings` | Configurações |
| `HomeIcon` | `Home` | Página inicial |
| `DocumentIcon` | `FileText` | Documento |
| `FolderIcon` | `Folder` | Pasta |
| `TrashIcon` | `Trash2` | Lixeira |
| `PencilIcon` | `Edit` | Editar |
| `EyeIcon` | `Eye` | Visualizar |
| `EyeSlashIcon` | `EyeOff` | Ocultar |
| `PlusIcon` | `Plus` | Adicionar |
| `MinusIcon` | `Minus` | Remover |
| `XMarkIcon` | `X` | Fechar |
| `CheckIcon` | `Check` | Confirmar |
| `ArrowLeftIcon` | `ArrowLeft` | Seta esquerda |
| `ArrowRightIcon` | `ArrowRight` | Seta direita |
| `ChevronDownIcon` | `ChevronDown` | Seta para baixo |
| `ChevronUpIcon` | `ChevronUp` | Seta para cima |

### Script de Migração Automática

```bash
#!/bin/bash
# migrate-icons.sh - Script para migrar automaticamente os ícones

# Criar backup
cp -r src src_backup

# Substituições comuns
find src -name "*.tsx" -o -name "*.ts" | xargs sed -i \
  -e 's/MagnifyingGlassIcon/Search/g' \
  -e 's/Bars3Icon/Menu/g' \
  -e 's/UserIcon/User/g' \
  -e 's/CogIcon/Settings/g' \
  -e 's/HomeIcon/Home/g' \
  -e 's/DocumentIcon/FileText/g' \
  -e 's/FolderIcon/Folder/g' \
  -e 's/TrashIcon/Trash2/g' \
  -e 's/PencilIcon/Edit/g' \
  -e 's/EyeIcon/Eye/g' \
  -e 's/EyeSlashIcon/EyeOff/g' \
  -e 's/PlusIcon/Plus/g' \
  -e 's/MinusIcon/Minus/g' \
  -e 's/XMarkIcon/X/g' \
  -e 's/CheckIcon/Check/g' \
  -e 's/ArrowLeftIcon/ArrowLeft/g' \
  -e 's/ArrowRightIcon/ArrowRight/g' \
  -e 's/ChevronDownIcon/ChevronDown/g' \
  -e 's/ChevronUpIcon/ChevronUp/g'

# Substituir importações
find src -name "*.tsx" -o -name "*.ts" | xargs sed -i \
  's/@heroicons\/react\/24\/outline/lucide-react/g'

echo "Migração concluída! Verifique os arquivos e teste a aplicação."
```

## Componentes Otimizados

### Componente de Ícone Universal
```typescript
// components/ui/icon.tsx
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface IconProps {
  icon: LucideIcon;
  size?: number | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  strokeWidth?: number;
}

export function Icon({ 
  icon: IconComponent, 
  size = 'md', 
  className,
  strokeWidth = 2 
}: IconProps) {
  const getSizeClass = (size: IconProps['size']) => {
    if (typeof size === 'number') {
      return { width: size, height: size };
    }
    
    const sizeMap = {
      xs: 'w-3 h-3',
      sm: 'w-4 h-4',
      md: 'w-6 h-6',
      lg: 'w-8 h-8',
      xl: 'w-12 h-12'
    };
    
    return sizeMap[size];
  };

  const sizeProps = typeof size === 'number' 
    ? { style: getSizeClass(size) }
    : { className: getSizeClass(size) };

  return (
    <IconComponent 
      {...sizeProps}
      strokeWidth={strokeWidth}
      className={cn(sizeProps.className, className)} 
    />
  );
}
```

### Hook para Ícones Dinâmicos
```typescript
// hooks/use-dynamic-icon.ts
import { useMemo } from 'react';
import * as LucideIcons from 'lucide-react';

export function useDynamicIcon(iconName: string) {
  return useMemo(() => {
    const IconComponent = (LucideIcons as any)[iconName];
    return IconComponent || LucideIcons.HelpCircle;
  }, [iconName]);
}

// Uso
function DynamicIconComponent({ iconName }: { iconName: string }) {
  const IconComponent = useDynamicIcon(iconName);
  return <IconComponent className="w-6 h-6" />;
}
```

## Configurações de Build Avançadas

### Webpack Bundle Analyzer
```typescript
// next.config.ts
import { BundleAnalyzerPlugin } from 'webpack-bundle-analyzer';

const nextConfig = {
  webpack: (config, { isServer }) => {
    if (process.env.ANALYZE === 'true') {
      config.plugins.push(
        new BundleAnalyzerPlugin({
          analyzerMode: 'server',
          openAnalyzer: true,
        })
      );
    }

    // Otimização específica para ícones
    config.optimization.splitChunks.cacheGroups.icons = {
      test: /[\\/]node_modules[\\/](lucide-react)[\\/]/,
      name: 'icons',
      chunks: 'all',
      priority: 10,
    };

    return config;
  },
};
```

### ESLint Rules Customizadas
```json
// .eslintrc.json
{
  "extends": ["next/core-web-vitals"],
  "rules": {
    "no-restricted-imports": [
      "error",
      {
        "patterns": [
          {
            "group": ["@heroicons/react/*"],
            "message": "Use lucide-react instead of @heroicons/react"
          }
        ]
      }
    ]
  }
}
```

## Testes Automatizados

### Teste de Componente com Ícones
```typescript
// __tests__/components/icon.test.tsx
import { render, screen } from '@testing-library/react';
import { Search } from 'lucide-react';
import { Icon } from '@/components/ui/icon';

describe('Icon Component', () => {
  it('renders icon with correct size', () => {
    render(<Icon icon={Search} size="lg" data-testid="search-icon" />);
    
    const icon = screen.getByTestId('search-icon');
    expect(icon).toHaveClass('w-8', 'h-8');
  });

  it('applies custom className', () => {
    render(
      <Icon 
        icon={Search} 
        className="text-blue-500" 
        data-testid="search-icon" 
      />
    );
    
    const icon = screen.getByTestId('search-icon');
    expect(icon).toHaveClass('text-blue-500');
  });
});
```

## Monitoramento de Performance

### Core Web Vitals
```typescript
// lib/web-vitals.ts
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

function sendToAnalytics(metric: any) {
  // Enviar métricas para seu serviço de analytics
  console.log(metric);
}

export function reportWebVitals() {
  getCLS(sendToAnalytics);
  getFID(sendToAnalytics);
  getFCP(sendToAnalytics);
  getLCP(sendToAnalytics);
  getTTFB(sendToAnalytics);
}
```

### Lighthouse CI Configuration
```json
// lighthouserc.json
{
  "ci": {
    "collect": {
      "url": ["http://localhost:3000"],
      "numberOfRuns": 3
    },
    "assert": {
      "assertions": {
        "categories:performance": ["error", {"minScore": 0.9}],
        "categories:accessibility": ["error", {"minScore": 0.9}],
        "categories:best-practices": ["error", {"minScore": 0.9}],
        "categories:seo": ["error", {"minScore": 0.9}]
      }
    }
  }
}
```

## Conclusão

Este prompt corrigido e melhorado oferece:

1. **Solução imediata** para o erro de dependência
2. **Múltiplas alternativas** de implementação
3. **Melhores práticas** de desenvolvimento web moderno
4. **Otimizações de performance** específicas
5. **Ferramentas de migração** automatizada
6. **Testes e monitoramento** integrados

A implementação dessas melhorias resultará em um projeto mais robusto, performático e maintível, seguindo os padrões mais atuais da indústria de desenvolvimento web.


## Instruções de Implementação Passo a Passo

### Passo 1: Backup e Preparação
```bash
# 1. Criar backup do projeto atual
cp -r /caminho/do/seu/projeto /caminho/do/backup

# 2. Navegar para o diretório do projeto
cd /caminho/do/seu/projeto

# 3. Verificar status atual
git status
git add .
git commit -m "Backup antes da correção de ícones"
```

### Passo 2: Correção Imediata do Erro

#### Opção A: Instalar @heroicons/react (Solução Rápida)
```bash
# Usando npm
npm install @heroicons/react

# Usando yarn
yarn add @heroicons/react

# Usando bun
bun add @heroicons/react

# Testar o build
npm run build
# ou
yarn build
# ou
bun run build
```

#### Opção B: Migrar para Lucide React (Recomendado)
```bash
# 1. Executar script de migração automática
find src -name "*.tsx" -o -name "*.ts" | xargs sed -i \
  -e 's/@heroicons\/react\/24\/outline/lucide-react/g' \
  -e 's/@heroicons\/react\/24\/solid/lucide-react/g' \
  -e 's/MagnifyingGlassIcon/Search/g' \
  -e 's/Bars3Icon/Menu/g' \
  -e 's/UserIcon/User/g' \
  -e 's/CogIcon/Settings/g'

# 2. Verificar se há mais substituições necessárias
grep -r "@heroicons" src/

# 3. Testar o build
npm run build
```

### Passo 3: Verificação e Testes
```bash
# 1. Verificar se não há erros de importação
npm run lint

# 2. Verificar tipos TypeScript
npm run type-check

# 3. Executar em modo desenvolvimento
npm run dev

# 4. Testar a aplicação no navegador
# Abrir http://localhost:3000 e verificar se os ícones aparecem corretamente
```

### Passo 4: Otimizações Adicionais (Opcional)

#### Implementar Componente de Ícone Universal
```bash
# 1. Criar diretório para componentes UI
mkdir -p src/components/ui

# 2. Criar arquivo do componente de ícone
cat > src/components/ui/icon.tsx << 'EOF'
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface IconProps {
  icon: LucideIcon;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function Icon({ icon: IconComponent, size = 'md', className }: IconProps) {
  const sizeClasses = {
    xs: 'w-3 h-3',
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  };

  return (
    <IconComponent 
      className={cn(sizeClasses[size], className)} 
    />
  );
}
EOF
```

#### Atualizar next.config.ts
```bash
# Backup da configuração atual
cp next.config.ts next.config.ts.backup

# Aplicar otimizações (editar manualmente ou usar o exemplo fornecido)
```

### Passo 5: Validação Final
```bash
# 1. Build de produção
npm run build

# 2. Testar build de produção
npm run start

# 3. Executar testes (se existirem)
npm run test

# 4. Verificar bundle size
npm run analyze  # se configurado

# 5. Commit das alterações
git add .
git commit -m "Corrigir erro de ícones e implementar melhorias de performance"
```

## Checklist de Verificação

### ✅ Correção do Erro Principal
- [ ] Erro `Module not found: @heroicons/react` resolvido
- [ ] Build executa sem erros
- [ ] Aplicação inicia corretamente
- [ ] Ícones são exibidos na interface

### ✅ Otimizações Implementadas
- [ ] Dependências desnecessárias removidas
- [ ] Importações otimizadas para tree-shaking
- [ ] Componente de ícone reutilizável criado
- [ ] Configuração de build otimizada

### ✅ Qualidade do Código
- [ ] ESLint passa sem erros
- [ ] TypeScript compila sem erros
- [ ] Testes passam (se existirem)
- [ ] Performance mantida ou melhorada

## Troubleshooting

### Problema: Ainda há erros de importação
**Solução:**
```bash
# Buscar por todas as importações problemáticas
grep -r "@heroicons" src/
grep -r "from.*heroicons" src/

# Substituir manualmente ou usar sed
sed -i 's/@heroicons\/react\/24\/outline/lucide-react/g' arquivo_problema.tsx
```

### Problema: Ícones não aparecem na tela
**Solução:**
```bash
# Verificar se lucide-react está instalado
npm list lucide-react

# Verificar importações
grep -r "import.*lucide-react" src/

# Verificar se os nomes dos ícones estão corretos
```

### Problema: Build muito lento
**Solução:**
```bash
# Analisar bundle
npm run analyze

# Verificar se há importações desnecessárias
# Implementar code splitting se necessário
```

### Problema: Tipos TypeScript incorretos
**Solução:**
```bash
# Reinstalar tipos
npm install --save-dev @types/react @types/react-dom

# Verificar versões de compatibilidade
npm list react react-dom typescript
```

## Suporte e Recursos Adicionais

### Documentação Oficial
- [Lucide React](https://lucide.dev/guide/packages/lucide-react)
- [Next.js Optimization](https://nextjs.org/docs/app/building-your-application/optimizing)
- [React Icons](https://react-icons.github.io/react-icons/)

### Ferramentas Úteis
- [Bundle Analyzer](https://www.npmjs.com/package/@next/bundle-analyzer)
- [Lighthouse CI](https://github.com/GoogleChrome/lighthouse-ci)
- [ESLint Plugin React](https://github.com/jsx-eslint/eslint-plugin-react)

### Comunidade e Ajuda
- [Next.js Discord](https://discord.gg/nextjs)
- [React Community](https://reactjs.org/community/support.html)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/next.js)

---

**Nota Final:** Este prompt corrigido resolve o erro original e implementa melhorias significativas baseadas nas melhores práticas atuais de desenvolvimento web. A migração para `lucide-react` é recomendada por ser uma biblioteca mais moderna, bem mantida e com melhor performance, mas a instalação do `@heroicons/react` também resolve o problema imediato se preferir manter a biblioteca original.

